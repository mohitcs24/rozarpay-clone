## ⭐ Razorpay Clone ⭐

It's a website that has been designed to mimic the design of the popular Indian payment gateway, Razorpay.

⭕ **This Site is Fully Responsive**
<br>
<br>

## 📌 **Live Site URL:** <a href="https://razorpay-copy.netlify.app/">**Visit Now** 🚀</a>

<br>

## 📌 Tech Stack

[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/prakash-naikwadi)&nbsp;
[![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)](https://github.com/prakash-naikwadi)&nbsp;
<img alt="TailwindCSS" src="https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white"/>&nbsp;
<br>
<br>

## 📬 Connect With Me

- **LinkedIn** - [Indra Shekhar](https://www.linkedin.com/in/indra-shekhar/)
- **Twitter** - [@Indra684](https://twitter.com/Indra684)
